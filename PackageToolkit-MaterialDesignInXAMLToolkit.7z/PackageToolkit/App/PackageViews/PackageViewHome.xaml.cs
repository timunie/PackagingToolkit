using System.Configuration;
using System.Windows;
using PackagingToolkit.Domain;

namespace PackagingToolkit.PackageViews
{
    public partial class PackageViewHome
    {
        public PackageViewHome() => InitializeComponent();
    }
}
