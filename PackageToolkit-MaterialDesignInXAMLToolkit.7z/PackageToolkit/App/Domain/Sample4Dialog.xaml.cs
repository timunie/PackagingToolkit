﻿using System.Windows.Controls;

namespace PackagingToolkit.Domain
{
    /// <summary>
    /// Interaction logic for SampleDialog.xaml
    /// </summary>
    public partial class Sample4Dialog : UserControl
    {
        public Sample4Dialog()
        {
            InitializeComponent();
        }
    }
}
