﻿using System.Windows.Controls;

namespace PackagingToolkit.Domain
{
    /// <summary>
    /// Interaction logic for DocumentationLinks.xaml
    /// </summary>
    public partial class DocumentationLinks : UserControl
    {
        public DocumentationLinks()
        {
            InitializeComponent();
        }
    }
}
