﻿namespace PackagingToolkit.Domain
{
    public enum DocumentationLinkType
    {
        Wiki,
        DemoPageSource,
        ControlSource,
        StyleSource,
        Video
    }
}