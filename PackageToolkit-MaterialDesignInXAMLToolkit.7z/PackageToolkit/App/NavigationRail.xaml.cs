﻿namespace PackagingToolkit
{
    public partial class NavigationRail
    {
        public NavigationRail() => InitializeComponent();
    }
}
