﻿namespace PackagingToolkit
{
    public partial class Transitions
    {
        public Transitions() => InitializeComponent();
    }
}
