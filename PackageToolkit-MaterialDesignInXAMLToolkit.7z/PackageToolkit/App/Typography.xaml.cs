﻿namespace PackagingToolkit
{
    public partial class Typography
    {
        public Typography() => InitializeComponent();
    }
}
