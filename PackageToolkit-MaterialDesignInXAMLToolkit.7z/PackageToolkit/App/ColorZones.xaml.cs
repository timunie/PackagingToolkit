﻿namespace PackagingToolkit
{
    public partial class ColorZones
    {
        public ColorZones() => InitializeComponent();
    }
}
