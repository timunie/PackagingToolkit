﻿namespace PackagingToolkit
{
    public partial class Drawers
    {
        public Drawers() => InitializeComponent();
    }
}
