﻿namespace PackagingToolkit
{
    public partial class GroupBoxes
    {
        public GroupBoxes() => InitializeComponent();
    }
}
