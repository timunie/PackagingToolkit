﻿using PackagingToolkit.Domain;

namespace PackagingToolkit
{
    public partial class Sliders
    {
        public Sliders()
        {
            DataContext = new SlidersViewModel();
            InitializeComponent();
        }
    }
}
