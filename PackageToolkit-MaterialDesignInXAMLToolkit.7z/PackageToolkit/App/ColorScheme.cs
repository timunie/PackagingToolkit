﻿namespace PackagingToolkit
{
    enum ColorScheme
    {
        Primary,
        Secondary,
        PrimaryForeground,
        SecondaryForeground
    }
}
