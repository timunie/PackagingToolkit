﻿using PackagingToolkit.Domain;

namespace PackagingToolkit
{
    public partial class DataGrids
    {
        public DataGrids()
        {
            DataContext = new ListsAndGridsViewModel();
            InitializeComponent();
        }
    }
}
