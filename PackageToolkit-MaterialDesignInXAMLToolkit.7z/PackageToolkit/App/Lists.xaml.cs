﻿using PackagingToolkit.Domain;

namespace PackagingToolkit
{
    public partial class Lists
    {
        public Lists()
        {
            DataContext = new ListsAndGridsViewModel();
            InitializeComponent();
        }
    }
}
