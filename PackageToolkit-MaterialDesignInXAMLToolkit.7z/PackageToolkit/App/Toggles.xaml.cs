﻿namespace PackagingToolkit
{
    public partial class Toggles
    {
        public Toggles() => InitializeComponent();

    }
}
