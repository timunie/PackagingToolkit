﻿namespace PackagingToolkit
{
    public partial class Progress
    {
        public Progress() => InitializeComponent();
    }
}
