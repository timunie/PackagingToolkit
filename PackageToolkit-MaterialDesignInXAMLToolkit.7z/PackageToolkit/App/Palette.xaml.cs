﻿namespace PackagingToolkit
{
    public partial class Palette
    {
        public Palette() => InitializeComponent();
    }
}
