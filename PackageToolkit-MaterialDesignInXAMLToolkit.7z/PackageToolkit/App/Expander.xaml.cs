﻿namespace PackagingToolkit
{
    public partial class Expander
    {
        public Expander() => InitializeComponent();
    }
}
