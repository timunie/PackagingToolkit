﻿namespace PackagingToolkit
{
    public partial class Shadows
    {
        public Shadows() => InitializeComponent();
    }
}
