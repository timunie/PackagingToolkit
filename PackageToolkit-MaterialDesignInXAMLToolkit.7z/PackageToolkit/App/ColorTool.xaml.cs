﻿using PackagingToolkit.Domain;

namespace PackagingToolkit
{
    public partial class ColorTool
    {
        public ColorTool()
        {
            DataContext = new ColorToolViewModel();
            InitializeComponent();
        }
    }
}
